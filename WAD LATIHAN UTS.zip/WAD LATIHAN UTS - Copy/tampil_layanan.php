<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Selatan</title>
    <style>
        h1{
            width: auto;
            text-align: center;
            margin-top: 10rem;
            color: #75753F;
            color-scheme: #0000,#5644;
        }
    </style>
</head>

<body>
    <h1>
        Selesai:)
    </h1>
</body>

</html>