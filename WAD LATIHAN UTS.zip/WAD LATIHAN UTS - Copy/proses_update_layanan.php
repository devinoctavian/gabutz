<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {
    $id=$_POST['id'];
    $nama_layanan = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];
    $durasi = $_POST['durasi'];
    $kategori = $_POST['kategori'];
    $status = $_POST['status'];
    $gambar = isset($_POST['gambar']);

    $nama_layanan = mysqli_real_escape_string($conn, $nama_layanan);
    $deskripsi = mysqli_real_escape_string($conn, $deskripsi);
    $harga = mysqli_real_escape_string($conn, $harga);
    $durasi = mysqli_real_escape_string($conn, $durasi);
    $nama_gambar = mysqli_real_escape_string($conn, $gambar);

    if (empty($nama_layanan) or empty($deskripsi) or empty($harga) or empty($durasi) or empty($nama_gambar)) {
        header("form_edit_layanan.php");
    }
    if (empty($nama_layanan)) $errors[] = "Nama layanan tidak boleh kosong";
    if (empty($deskripsi)) $errors[] = "Deskripsi tidak boleh kosong";
    if (empty($harga) || !is_numeric($harga) || $harga <= 0) {
        $errors[] = "Harga harus berupa angka positif";
    }
    if (empty($durasi) || !is_numeric($durasi) || $durasi <= 0) {
        $errors[] = "Durasi harus berupa angka positif";
    }

    $nama_gambar = isset($gambar_lama);

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['gambar']['tmp_name'];
            $file_name = $_FILES['gambar']['name'];
            $file_size = $_FILES['gambar']['size'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($file_ext, $allowed_ext)) {
                $errors[] = "Format gambar tidak valid. Hanya JPG, JPEG, PNG, dan GIF yang diizinkan";
            }

            if ($file_size > 2097152) {
                $errors[] = "Ukuran gambar terlalu besar. Maksimal 2MB";
            }

            if (empty($errors)) {
                $nama_gambar = 'layanan_' . time() . '_' . uniqid() . '.' . $file_ext;
                $upload_dir = 'uploads/layanan/';

                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                if (move_uploaded_file($file_tmp, $upload_dir . $nama_gambar)) {
                    if (!empty($gambar_lama) && file_exists($upload_dir . $gambar_lama)) {
                        unlink($upload_dir . $gambar_lama);
                    }
                } else {
                    $errors[] = "Gagal mengupload gambar";
                }
            }
        } else {
            $errors[] = "Terjadi kesalahan saat mengupload gambar";
        }
    }

    $query = "UPDATE layanan
                SET nama_layanan='$nama_layanan',
                deskripsi='$deskripsi',
                harga='$harga',
                durasi='$durasi',
                kategori='$kategori',
                status='$status',
                gambar='$gambar',
                updated_at=NOW()
            WHERE id_layanan=$id";
    mysqli_query($conn, $query);

    if (mysqli_affected_rows($conn) > 0) {
        header("Location: tampil_layanan.php");
        exit;
    } else {
        echo "
        <script>
            alert('Failed to add services'); 
            window.location='tampil_layanan.php';
        </script>";
    }
}
