<?php 
include 'koneksi.php';
$id=$_GET['id'];
$query="SELECT * FROM layanan WHERE id_layanan=$id"; 
$result=mysqli_query($conn,$query);
$data=mysqli_fetch_assoc($result);
?>

<h3>📄Form Edit Layanan</h3>
<form action="proses_update_layanan.php" method="POST" enctype="multipart/form-data">
    <label for="nama">Nama Layanan</label><br>
    <input type="hidden" name="id" value="<?=$id?>">
    <input type="text" id="nama" name="nama" placeholder="Nama Layanan" required value="<?=$data['nama_layanan']?>"><br><br>

    <label for="deskripsi">Deskripsi Layanan</label><br>
    <textarea id="deskripsi" id="deskripsi" name="deskripsi" placeholder="Deskripsi Layanan" rows="3" required>
        <?=$data['deskripsi']?>
    </textarea><br><br>
    
    <label for="harga">Harga</label><br>
    <input type="number" id="harga" name="harga" placeholder="Harga" required value="<?=$data['harga']?>"><br><br>

    <label for="durasi">Durasi</label><br>
    <input type="number" id="durasi" name="durasi" placeholder="Durasi" min="1" required value="<?=$data['durasi']?>"><br><br>

    <label for="kategori">Kategori</label><br>
    <select name="kategori" id="kategori" required>
        <option value="">-- Pilih Kategori --</option>
        <option <?php if($data['kategori']=="Pengembangan Perangkat Lunak"){echo "selected";}?>value="Pengembangan Perangkat Lunak">Pengembangan Perangkat Lunak</option>
        <option <?php if($data['kategori']=="Desain Antarmuka & Pengalaman Pengguna"){echo "selected";}?>value="Desain Antarmuka & Pengalaman Pengguna">Desain Antarmuka & Pengalaman Pengguna</option>
        <option <?php if($data['kategori']=="Digital Marketing"){echo "selected";}?>value="Digital Marketing">Digital Marketing</option>
    </select><br><br>

    <label for="status">Status</label><br>
    <select id="status" name="status" placeholder="Status" required value="<?=$data['status']?>">
        <option value="Aktif">Aktif</option>
        <option value="Tidak Aktif">Tidak Aktif</option>
    </select><br><br>

    <label for="gambar">Gambar</label><br>
    <input type="file" id="gambar" name="gambar" accept="image/*" value="<?=$data['durasi']?>"><br><br>

    <button type="submit" name="submit">Simpan Layanan</button>
</form>    